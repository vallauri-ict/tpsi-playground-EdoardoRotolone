
let nUsers = 0;
let k = 0;
let i = 0;
let parita = 0;
let userdata2;
window.onload = function () {
    nUsers = 1;
    generaUsers();
    k++;

}
function generaUsers() {
    //nUsers = document.getElementById("num").value;
    let _chk = document.getElementsByName("chk");
    let _radio = document.getElementsByName("radio");
    let l = 0;
    //if(_chkIT.checked/*value*/  == true){
    //alert("gangang");
    //}

    if (k != 0) {
        l = document.getElementById("slider").value;
        nUsers = Math.floor(l/5);
    }
    b = nUsers;
    let param = "?results=" + nUsers;
    let finalURL = "https://randomuser.me/api/" + param;
    let s = "";
    for (let i = 0; i < _chk.length; i++) {
        if (_chk[i].checked){
            if (s == "") {
                s += "&nat=" + _chk[i].value;
            } else {
                s += "," + _chk[i].value;
            }
    }
    }
    if(s!="") {
        finalURL += s;
    }
    let gender = "";
    for (let i = 0; i<_radio.length; i++){
        if(_radio[i].checked){
            if(gender==""){
                gender += "&gender=" + _radio[i].value;
            } else {
                gender += "," + _radio[i].value;
            }
        }
        if(gender!="")
            finalURL += gender;
    }

    console.log(finalURL);
     //url finale, esempio. Numero inserito: 4. risultato:https://randomusers.me/api/?results4
    //console.log(finalURL);
    $.ajax({ //funzione
        url: finalURL,
        dataType: 'json',
        success: function (usersData) {
            console.log(usersData);
            userdata2 = usersData;
            let _body = document.getElementById("ciao"); //dichiarazione del body nel js in modo da andare poi ad inserire dinamicamente dei contenuti
            let inp; //?
            let lbl; //label che stamperà poi i contenuti e li renderà visibili
            let img;
            let div = document.createElement("div"); //creazione di un div
            /*let _contenuto = document.getElementsByName("contenuto");
            _contenuto.setAttribute("value",usersData.results[i].name.first+ " "+usersData.results[i].name.last);*/
            /*div.style.marginTop = "400px"
            div.style.marginLeft = "720px";*/
            //div.setAttribute("class","valoreGenerato");
            _body.appendChild(div); //applicazione del div sulla pagina
            for (let i = 0; i < nUsers; i++) {
                visualizzaInfo(usersData, lbl, inp, div, i, img); //funzione ripetuta nel ciclo in modo da generare info casuali
            }
        }
    })
}

function visualizzaInfo(usersData, lbl, inp, div, i, img) {
    $("#lblContent").text(usersData.results[i].name.first + " " + usersData.results[i].name.last);
    $("#imgUser").attr("src", usersData.results[i].picture.large);
    $("#email").text(usersData.results[i].email);
    $("#address").text(usersData.results[i].location.street.number + " " + usersData.results[i].location.street.name);
    $("#tel").text(usersData.results[i].cell);
    $("#date").text(usersData.results[i].dob.date);
    $("#nat").text(usersData.results[i].nat);
    $("#gen").text(usersData.results[i].gender);
  //inp.innerHTML( usersData.results[i].name.first + " " + usersData.results[i].name.last);
}
 function changevalue() {
    let slider = document.getElementById("slider");
    let lblutenti = document.getElementById("labelSlider");
    slider.oninput = function () {
        lblutenti.innerHTML = Math.floor(this.value/5);
        let sli = document.getElementById("slider");
        sli.style.background = 'linear-gradient(to right, #83ba43 0%, #83ba43 ' + sli.value + '%, #fff ' + sli.value + '%, white 100%)';
    }
    lblutenti.innerHTML = Math.floor(slider.value/5);
     let sli = document.getElementById("slider");
     sli.style.background = 'linear-gradient(to right, #83ba43 0%, #83ba43 ' + sli.value + '%, #fff ' + sli.value + '%, white 100%)';
}
function changecolor() {
    let sli = document.getElementById("slider");
    sli.style.background = 'linear-gradient(to right, #83ba43 0%, #83ba43 ' + sli.value + '%, #fff ' + sli.value + '%, white 100%)'
}
  function showInfo() {
    //document.getElementById("btnShow").hidden = 'true';
    parita++;
    if(parita%2!=0) {
      $("#w2").animate({marginTop: '960px'})
      $(".wrapper").animate({width:'1960px'})
      $("#card").animate({height:'1200px'})
      $("#id").animate({marginLeft:'145px'})
      $("#btnShow").text("Close Info");
      $("#display").css('margin', 'auto');
      //$("#id").css('margin-left',145 + 'px');
      document.getElementById("display").style.display = 'inline';
      /*document.getElementById("card").style.width = '2700px';
      document.getElementById("card").style.height = '1200px';
      document.getElementById("w2").style.marginTop = '960px';*/
    }
    else{
      $("#w2").animate({marginTop: '200px'})
      $("#card").animate({height:'490px'})
      $(".wrapper").animate({width:'1670px'})
      $("#card").animate({width:'1700px'})
      $("#btnShow").text("View All Info");
      $("#id").animate({marginLeft:'0px'})
      $("#display").animate({display: 'none'})
      document.getElementById("display").style.display = 'none';
     /* document.getElementById("card").style.width = '1700px';
      document.getElementById("card").style.height = '490px';
      document.getElementById("w2").style.marginTop = '200px';*/
    }
  }

function control() {
  if (nUsers>1) {
    if(i<nUsers-1) {
      i++;
      $("#lblContent").text(userdata2.results[i].name.first + " " + userdata2.results[i].name.last);
      $("#imgUser").attr("src", userdata2.results[i].picture.large);
      $("#email").text(userdata2.results[i].email);
      $("#address").text(userdata2.results[i].location.street.number + " " + userdata2.results[i].location.street.name);
      $("#tel").text(userdata2.results[i].cell);
      $("#date").text(userdata2.results[i].dob.date);
      $("#nat").text(userdata2.results[i].nat);
      $("#gen").text(userdata2.results[i].gender);
    }
  }
}
function control2() {
  if (nUsers>1) {
    if (i>0) {
      i--;
      $("#lblContent").text(userdata2.results[i].name.first + " " + userdata2.results[i].name.last);
      $("#imgUser").attr("src", userdata2.results[i].picture.large);
      $("#email").text(userdata2.results[i].email);
      $("#address").text(userdata2.results[i].location.street.number + " " + userdata2.results[i].location.street.name);
      $("#tel").text(userdata2.results[i].cell);
      $("#date").text(userdata2.results[i].dob.date);
      $("#nat").text(userdata2.results[i].nat);
      $("#gen").text(userdata2.results[i].gender);
    }
  }
}
function mouseover() {
   $("#lblContent").text(userdata2.results[i].email);

}
function mouseover1() {
  $("#lblContent").text(userdata2.results[i].name.first + " " + userdata2.results[i].name.last);

}
function mouseover2() {
  $("#lblContent").text(userdata2.results[i].dob.date);

}
function mouseover3() {
  $("#lblContent").text(userdata2.results[i].location.street.number + " " + userdata2.results[i].location.street.name);

}
function mouseover4() {
  $("#lblContent").text(userdata2.results[i].cell);

}
function mouseover5() {
  $("#lblContent").text(userdata2.results[i].login.password);

}


