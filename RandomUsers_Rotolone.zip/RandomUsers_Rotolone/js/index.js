"use strict"
let nUsers = 0;
let k = 0;
window.onload = function () {
    nUsers = 1;
    generaUsers();
    k++;
}


function generaUsers() {
    //nUsers = document.getElementById("num").value;
    let _chk = document.getElementsByName("chk");
    let _radio = document.getElementsByName("radio");
    let i = 0;
    //if(_chkIT.checked/*value*/  == true){
    //alert("gangang");
    //}

    if (k != 0) {
        nUsers = document.getElementById("num").value;
    }
    let param = "?results=" + nUsers;
    let finalURL = "https://randomuser.me/api/" + param;
    let s = "";
    for (let i = 0; i < _chk.length; i++) {
        if (_chk[i].checked){
            if (s == "") {
                s += "&nat=" + _chk[i].value;
            } else {
                s += "," + _chk[i].value;
            }
    }
    }
    if(s!="") {
        finalURL += s;
    }
    let gender = "";
    for (let i = 0; i<_radio.length; i++){
        if(_radio[i].checked){
            if(gender==""){
                gender += "&gender=" + _radio[i].value;
            } else {
                gender += "," + _radio[i].value;
            }
        }
        if(gender!="")
            finalURL += gender;
    }

    console.log(finalURL);
     //url finale, esempio. Numero inserito: 4. risultato:https://randomusers.me/api/?results4
    //console.log(finalURL);
    $.ajax({ //funzione
        url: finalURL,
        dataType: 'json',
        success: function (usersData) {
            console.log(usersData);
            let _body = document.getElementById("ciao"); //dichiarazione del body nel js in modo da andare poi ad inserire dinamicamente dei contenuti
            let inp; //?
            let lbl; //label che stamperà poi i contenuti e li renderà visibili
            let div = document.createElement("div"); //creazione di un div
            /*let _contenuto = document.getElementsByName("contenuto");
            _contenuto.setAttribute("value",usersData.results[i].name.first+ " "+usersData.results[i].name.last);*/
            div.setAttribute("float", "left"); //impostazione degli attributi del div
            div.setAttribute("text-align", "center");
            //div.setAttribute("class","valoreGenerato");
            _body.appendChild(div); //applicazione del div sulla pagina
            for (let i = 0; i < nUsers; i++) {
                visualizzaInfo(usersData, lbl, inp, div, i); //funzione ripetuta nel ciclo in modo da generare info casuali
            }
        }
    })
}

function visualizzaInfo(usersData, lbl, inp, div, i) {
    inp = document.createElement("input");
    inp.setAttribute("type", "text");
    inp.setAttribute("class", "nominativo");
    inp.setAttribute("disabled", "true");
    inp.setAttribute("value", usersData.results[i].name.first + " " + usersData.results[i].name.last);
    lbl = document.createElement("label");
    div.appendChild(lbl);
    lbl.innerHTML += "Nome e cognome";
    div.appendChild(inp);
    div.innerHTML += "<br/>";
}


/*
let nome = new Array("Edoardo","Roberto","Alessandro","Luca","Nicolas");
let cognome = new Array("Rotolone","Mottura","Gribaudo","Marchisio","Dovetta");
let data = new Array("21/04/2002", "21/07/2003", "01/07/2003", "06/02/2003", "20/09/2002");
let email = new Array ("abcdrfghi@gmail.com","123456@gmail.com","98765432#gmail.com","ihgfrdcba@gmail.com","ciaociao@gmail.com");
window.onload = function () {
        let iNome = 0;
        let iCognome = 0;
        let iData = 0;
        let iEmail = 0;
        iNome = Math.floor((Math.random() * 4) + 0);
        iCognome = Math.floor((Math.random() * 4) + 0);
        iData =  Math.floor((Math.random() * 4) + 0);
        iEmail = Math.floor((Math.random() * 4) + 0);
        console.log(nome[iNome] + " " + cognome[iCognome] + " " + data[iData]+ " " + email[iEmail]);
}
*/
