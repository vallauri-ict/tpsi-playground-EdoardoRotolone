"use strict"
let nUsers = 0;
let k = 0;
window.onload = function () {
    nUsers = 1;
    generaUsers();
    k++;
}
function generaUsers() {
    //nUsers = document.getElementById("num").value;
    let _chk = document.getElementsByName("chk");
    let _radio = document.getElementsByName("radio");
    let i = 0;
    let l = 0;
    //if(_chkIT.checked/*value*/  == true){
    //alert("gangang");
    //}

    if (k != 0) {
        l = document.getElementById("slider").value;
        nUsers = Math.floor(l/5);
    }
    let param = "?results=" + nUsers;
    let finalURL = "https://randomuser.me/api/" + param;
    let s = "";
    for (let i = 0; i < _chk.length; i++) {
        if (_chk[i].checked){
            if (s == "") {
                s += "&nat=" + _chk[i].value;
            } else {
                s += "," + _chk[i].value;
            }
    }
    }
    if(s!="") {
        finalURL += s;
    }
    let gender = "";
    for (let i = 0; i<_radio.length; i++){
        if(_radio[i].checked){
            if(gender==""){
                gender += "&gender=" + _radio[i].value;
            } else {
                gender += "," + _radio[i].value;
            }
        }
        if(gender!="")
            finalURL += gender;
    }

    console.log(finalURL);
     //url finale, esempio. Numero inserito: 4. risultato:https://randomusers.me/api/?results4
    //console.log(finalURL);
    $.ajax({ //funzione
        url: finalURL,
        dataType: 'json',
        success: function (usersData) {
            console.log(usersData);
            let _body = document.getElementById("ciao"); //dichiarazione del body nel js in modo da andare poi ad inserire dinamicamente dei contenuti
            let inp; //?
            let lbl; //label che stamperà poi i contenuti e li renderà visibili
            let div = document.createElement("div"); //creazione di un div
            /*let _contenuto = document.getElementsByName("contenuto");
            _contenuto.setAttribute("value",usersData.results[i].name.first+ " "+usersData.results[i].name.last);*/
            div.setAttribute("float", "left"); //impostazione degli attributi del div
            div.setAttribute("text-align", "center");
            /*div.style.marginTop = "400px"
            div.style.marginLeft = "720px";*/
            //div.setAttribute("class","valoreGenerato");
            _body.appendChild(div); //applicazione del div sulla pagina
            for (let i = 0; i < nUsers; i++) {
                visualizzaInfo(usersData, lbl, inp, div, i); //funzione ripetuta nel ciclo in modo da generare info casuali
            }
        }
    })
}

function visualizzaInfo(usersData, lbl, inp, div, i) {
    inp = document.createElement("input");
    inp.setAttribute("type", "text");
    inp.setAttribute("class", "nominativo");
    inp.setAttribute("disabled", "true");
    inp.setAttribute("value", usersData.results[i].name.first + " " + usersData.results[i].name.last);
    lbl = document.createElement("label");
    div.appendChild(lbl);
    lbl.innerHTML += "Nome e cognome";
    div.appendChild(inp);
    div.innerHTML += "<br/>";
}
 function changevalue() {
    let slider = document.getElementById("slider");
    let lblutenti = document.getElementById("labelSlider");
    slider.oninput = function () {
        lblutenti.innerHTML = Math.floor(this.value/5);
        let sli = document.getElementById("slider");
        sli.style.background = 'linear-gradient(to right, #83ba43 0%, #83ba43 ' + sli.value + '%, #fff ' + sli.value + '%, white 100%)';
    }
    lblutenti.innerHTML = Math.floor(slider.value/5);
     let sli = document.getElementById("slider");
     sli.style.background = 'linear-gradient(to right, #83ba43 0%, #83ba43 ' + sli.value + '%, #fff ' + sli.value + '%, white 100%)';
}
function changecolor() {
    let sli = document.getElementById("slider");
    sli.style.background = 'linear-gradient(to right, #83ba43 0%, #83ba43 ' + sli.value + '%, #fff ' + sli.value + '%, white 100%)'
}